@echo off
setlocal EnableExtensions

set "SOURCE_DIR=%~dp0"
set "PROJECT_DIR=%SOURCE_DIR%flutter_project"

where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter SDK was not found in PATH.
  echo Install Flutter and Android Studio, then reopen this window.
  pause
  exit /b 1
)

if not exist "%PROJECT_DIR%\pubspec.yaml" (
  echo Creating the Flutter platform scaffold...
  pushd "%SOURCE_DIR%"
  flutter create --project-name meeting_notes_app --platforms=android,ios flutter_project
  if errorlevel 1 (
    popd
    echo Failed to create the Flutter project.
    pause
    exit /b 1
  )
  popd
)

echo Copying application sources...
if exist "%PROJECT_DIR%\lib" rmdir /s /q "%PROJECT_DIR%\lib"
xcopy "%SOURCE_DIR%lib" "%PROJECT_DIR%\lib" /E /I /Y >nul
if errorlevel 1 goto copy_error

if exist "%PROJECT_DIR%\test" rmdir /s /q "%PROJECT_DIR%\test"
xcopy "%SOURCE_DIR%test" "%PROJECT_DIR%\test" /E /I /Y >nul
if errorlevel 1 goto copy_error

copy /Y "%SOURCE_DIR%pubspec.yaml" "%PROJECT_DIR%\pubspec.yaml" >nul
copy /Y "%SOURCE_DIR%analysis_options.yaml" "%PROJECT_DIR%\analysis_options.yaml" >nul

pushd "%PROJECT_DIR%"
echo Resolving dependencies...
flutter pub get
if errorlevel 1 (
  popd
  echo Dependency installation failed.
  pause
  exit /b 1
)
echo Available devices:
flutter devices
echo Starting the app...
flutter run
popd
exit /b 0

:copy_error
echo Failed to copy application files.
pause
exit /b 1
