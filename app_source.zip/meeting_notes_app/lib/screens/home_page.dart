import 'package:flutter/material.dart';

import '../data/file_note_repository.dart';
import '../data/note_repository.dart';
import '../data/sqlite_note_repository.dart';
import '../models/note.dart';
import '../utils/date_format.dart';
import 'note_editor_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _searchController = TextEditingController();
  StorageMode _storageMode = StorageMode.sqlite;
  NoteRepository? _repository;
  List<Note> _notes = [];
  DateTime? _filterDate;
  TimeOfDay? _filterTime;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
    _initializeRepository();
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    if (mounted) setState(() {});
  }

  NoteRepository _createRepository(StorageMode mode) {
    return switch (mode) {
      StorageMode.sqlite => SqliteNoteRepository(),
      StorageMode.files => FileNoteRepository(),
    };
  }

  Future<void> _initializeRepository() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final repository = _createRepository(_storageMode);
      await repository.initialize();
      final notes = await repository.getAll();
      if (!mounted) return;
      setState(() {
        _repository = repository;
        _notes = notes;
        _isLoading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = 'Не удалось открыть хранилище: $error';
        _isLoading = false;
      });
    }
  }

  Future<void> _reload() async {
    final repository = _repository;
    if (repository == null) return;
    try {
      final notes = await repository.getAll();
      if (!mounted) return;
      setState(() => _notes = notes);
    } catch (error) {
      _showMessage('Ошибка чтения заметок: $error');
    }
  }

  List<Note> get _visibleNotes {
    final query = _searchController.text.trim().toLowerCase();
    return _notes.where((note) {
      final textMatches = query.isEmpty ||
          note.title.toLowerCase().contains(query) ||
          note.content.toLowerCase().contains(query) ||
          formatDate(note.eventAt).contains(query) ||
          formatTime(note.eventAt).contains(query);

      final dateMatches = _filterDate == null ||
          (note.eventAt.year == _filterDate!.year &&
              note.eventAt.month == _filterDate!.month &&
              note.eventAt.day == _filterDate!.day);

      final timeMatches = _filterTime == null ||
          (note.eventAt.hour == _filterTime!.hour &&
              note.eventAt.minute == _filterTime!.minute);

      return textMatches && dateMatches && timeMatches;
    }).toList();
  }

  Future<void> _changeStorage(StorageMode mode) async {
    if (mode == _storageMode) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Сменить способ хранения?'),
        content: Text(
          'Будет открыто хранилище «${mode.label}». Заметки из текущего '
          'хранилища останутся на месте и автоматически не копируются.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Переключить'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _storageMode = mode);
    await _initializeRepository();
  }

  Future<void> _openEditor({Note? note}) async {
    final result = await Navigator.of(context).push<Note>(
      MaterialPageRoute(builder: (_) => NoteEditorPage(note: note)),
    );
    if (result == null) return;
    try {
      await _repository!.save(result);
      await _reload();
      _showMessage(note == null ? 'Заметка создана' : 'Изменения сохранены');
    } catch (error) {
      _showMessage('Не удалось сохранить заметку: $error');
    }
  }

  Future<void> _deleteNote(Note note) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Удалить заметку?'),
        content: Text('«${note.title}» будет удалена без возможности отмены.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Отмена'),
          ),
          FilledButton.tonal(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await _repository!.delete(note.id);
      await _reload();
      _showMessage('Заметка удалена');
    } catch (error) {
      _showMessage('Не удалось удалить заметку: $error');
    }
  }

  Future<void> _showFilters() async {
    DateTime? draftDate = _filterDate;
    TimeOfDay? draftTime = _filterTime;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Фильтры заметок'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.calendar_month_outlined),
                title: const Text('Дата мероприятия'),
                subtitle: Text(
                  draftDate == null ? 'Любая дата' : formatDate(draftDate!),
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () async {
                  final value = await showDatePicker(
                    context: dialogContext,
                    initialDate: draftDate ?? DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (value != null) {
                    setDialogState(() => draftDate = value);
                  }
                },
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.schedule),
                title: const Text('Время мероприятия'),
                subtitle: Text(
                  draftTime == null
                      ? 'Любое время'
                      : '${twoDigits(draftTime!.hour)}:${twoDigits(draftTime!.minute)}',
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () async {
                  final value = await showTimePicker(
                    context: dialogContext,
                    initialTime: draftTime ?? TimeOfDay.now(),
                  );
                  if (value != null) {
                    setDialogState(() => draftTime = value);
                  }
                },
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () => setDialogState(() {
                    draftDate = null;
                    draftTime = null;
                  }),
                  icon: const Icon(Icons.filter_alt_off_outlined),
                  label: const Text('Сбросить фильтры'),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Отмена'),
            ),
            FilledButton(
              onPressed: () {
                setState(() {
                  _filterDate = draftDate;
                  _filterTime = draftTime;
                });
                Navigator.pop(dialogContext);
              },
              child: const Text('Применить'),
            ),
          ],
        ),
      ),
    );
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final visibleNotes = _visibleNotes;
    final hasFilters = _filterDate != null || _filterTime != null;

    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Рабочие заметки'),
            Text(
              'Совещания • встречи • мероприятия',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.normal),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<StorageMode>(
            tooltip: 'Способ хранения',
            initialValue: _storageMode,
            onSelected: _changeStorage,
            itemBuilder: (context) => [
              PopupMenuItem(
                value: StorageMode.sqlite,
                child: _storageMenuItem(
                  Icons.storage_outlined,
                  'SQLite',
                  _storageMode == StorageMode.sqlite,
                ),
              ),
              PopupMenuItem(
                value: StorageMode.files,
                child: _storageMenuItem(
                  Icons.folder_outlined,
                  'Файлы JSON',
                  _storageMode == StorageMode.files,
                ),
              ),
            ],
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  const Icon(Icons.storage_outlined, size: 19),
                  const SizedBox(width: 5),
                  Text(_storageMode == StorageMode.sqlite ? 'SQLite' : 'Файлы'),
                  const Icon(Icons.arrow_drop_down),
                ],
              ),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      textInputAction: TextInputAction.search,
                      decoration: InputDecoration(
                        hintText: 'Поиск по заголовку, тексту, дате…',
                        prefixIcon: const Icon(Icons.search),
                        suffixIcon: _searchController.text.isEmpty
                            ? null
                            : IconButton(
                                tooltip: 'Очистить поиск',
                                onPressed: _searchController.clear,
                                icon: const Icon(Icons.close),
                              ),
                        filled: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Stack(
                    children: [
                      IconButton.filledTonal(
                        tooltip: 'Фильтр по дате и времени',
                        onPressed: _showFilters,
                        icon: const Icon(Icons.tune),
                      ),
                      if (hasFilters)
                        Positioned(
                          right: 7,
                          top: 7,
                          child: Container(
                            width: 9,
                            height: 9,
                            decoration: BoxDecoration(
                              color: theme.colorScheme.primary,
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            if (hasFilters)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Wrap(
                    spacing: 8,
                    children: [
                      if (_filterDate != null)
                        InputChip(
                          label: Text(formatDate(_filterDate!)),
                          onDeleted: () => setState(() => _filterDate = null),
                        ),
                      if (_filterTime != null)
                        InputChip(
                          label: Text(
                            '${twoDigits(_filterTime!.hour)}:${twoDigits(_filterTime!.minute)}',
                          ),
                          onDeleted: () => setState(() => _filterTime = null),
                        ),
                    ],
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 6, 20, 10),
              child: Row(
                children: [
                  Text(
                    'Мои заметки',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 9,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.secondaryContainer,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      '${visibleNotes.length}',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: theme.colorScheme.onSecondaryContainer,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    _storageMode.label,
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(child: _buildBody(visibleNotes)),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _isLoading || _error != null ? null : () => _openEditor(),
        icon: const Icon(Icons.add),
        label: const Text('Новая заметка'),
      ),
    );
  }

  Widget _storageMenuItem(IconData icon, String title, bool selected) {
    return Row(
      children: [
        Icon(icon, size: 20),
        const SizedBox(width: 12),
        Expanded(child: Text(title)),
        if (selected) const Icon(Icons.check, size: 18),
      ],
    );
  }

  Widget _buildBody(List<Note> notes) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 42),
              const SizedBox(height: 12),
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _initializeRepository,
                icon: const Icon(Icons.refresh),
                label: const Text('Повторить'),
              ),
            ],
          ),
        ),
      );
    }
    if (notes.isEmpty) {
      final hasSearch = _searchController.text.trim().isNotEmpty ||
          _filterDate != null ||
          _filterTime != null;
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                hasSearch ? Icons.search_off : Icons.note_add_outlined,
                size: 58,
                color: Theme.of(context).colorScheme.outline,
              ),
              const SizedBox(height: 16),
              Text(
                hasSearch ? 'Ничего не найдено' : 'Пока нет заметок',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 8),
              Text(
                hasSearch
                    ? 'Измените поисковый запрос или сбросьте фильтры.'
                    : 'Создайте первую заметку для совещания или встречи.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
              ),
            ],
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _reload,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
        itemCount: notes.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) => _NoteCard(
          note: notes[index],
          onTap: () => _openEditor(note: notes[index]),
          onEdit: () => _openEditor(note: notes[index]),
          onDelete: () => _deleteNote(notes[index]),
        ),
      ),
    );
  }
}

class _NoteCard extends StatelessWidget {
  const _NoteCard({
    required this.note,
    required this.onTap,
    required this.onEdit,
    required this.onDelete,
  });

  final Note note;
  final VoidCallback onTap;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final content = note.content.trim();

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 8, 14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(
                  Icons.description_outlined,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      note.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      content.isEmpty ? 'Нет текста заметки' : content,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                        height: 1.35,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Row(
                      children: [
                        Icon(
                          Icons.event_outlined,
                          size: 15,
                          color: theme.colorScheme.primary,
                        ),
                        const SizedBox(width: 5),
                        Text(
                          formatDateTime(note.eventAt),
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: theme.colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                tooltip: 'Действия с заметкой',
                onSelected: (value) {
                  if (value == 'edit') onEdit();
                  if (value == 'delete') onDelete();
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(
                    value: 'edit',
                    child: ListTile(
                      leading: Icon(Icons.edit_outlined),
                      title: Text('Редактировать'),
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                  PopupMenuItem(
                    value: 'delete',
                    child: ListTile(
                      leading: Icon(Icons.delete_outline),
                      title: Text('Удалить'),
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
