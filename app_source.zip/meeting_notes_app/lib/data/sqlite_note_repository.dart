import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/note.dart';
import 'note_repository.dart';

class SqliteNoteRepository implements NoteRepository {
  Database? _database;

  @override
  Future<void> initialize() async {
    if (_database != null) return;

    final databasesPath = await getDatabasesPath();
    final databasePath = p.join(databasesPath, 'meeting_notes.db');

    _database = await openDatabase(
      databasePath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE notes (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            eventAt INTEGER NOT NULL,
            createdAt INTEGER NOT NULL,
            updatedAt INTEGER NOT NULL
          )
        ''');
        await db.execute(
          'CREATE INDEX idx_notes_event_at ON notes(eventAt)',
        );
      },
    );
  }

  Database get _db {
    final database = _database;
    if (database == null) {
      throw StateError('SQLite repository has not been initialized.');
    }
    return database;
  }

  @override
  Future<List<Note>> getAll() async {
    final rows = await _db.query('notes', orderBy: 'eventAt DESC');
    return rows.map((row) => Note.fromMap(row)).toList();
  }

  @override
  Future<void> save(Note note) async {
    await _db.insert(
      'notes',
      note.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  @override
  Future<void> delete(String id) async {
    await _db.delete('notes', where: 'id = ?', whereArgs: [id]);
  }
}
