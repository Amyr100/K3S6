import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../models/note.dart';
import 'note_repository.dart';

class FileNoteRepository implements NoteRepository {
  Directory? _notesDirectory;

  @override
  Future<void> initialize() async {
    final documentsDirectory = await getApplicationDocumentsDirectory();
    final directory = Directory(p.join(documentsDirectory.path, 'meeting_notes'));
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    _notesDirectory = directory;
  }

  Directory get _directory {
    final directory = _notesDirectory;
    if (directory == null) {
      throw StateError('File repository has not been initialized.');
    }
    return directory;
  }

  @override
  Future<List<Note>> getAll() async {
    final notes = <Note>[];
    await for (final entity in _directory.list(followLinks: false)) {
      if (entity is! File || !entity.path.toLowerCase().endsWith('.json')) {
        continue;
      }
      try {
        final decoded = jsonDecode(await entity.readAsString());
        if (decoded is Map<String, dynamic>) {
          notes.add(Note.fromMap(decoded));
        }
      } on FormatException {
        // Ignore a damaged JSON file instead of preventing the whole list from
        // opening. The original file is left untouched for possible recovery.
      } on TypeError {
        // Ignore files that do not match the note schema.
      } on StateError {
        // Ignore structurally invalid note files.
      }
    }
    notes.sort((a, b) => b.eventAt.compareTo(a.eventAt));
    return notes;
  }

  @override
  Future<void> save(Note note) async {
    final file = File(p.join(_directory.path, '${note.id}.json'));
    final json = const JsonEncoder.withIndent('  ').convert(note.toMap());
    await file.writeAsString(json, flush: true);
  }

  @override
  Future<void> delete(String id) async {
    final file = File(p.join(_directory.path, '$id.json'));
    if (await file.exists()) {
      await file.delete();
    }
  }
}
