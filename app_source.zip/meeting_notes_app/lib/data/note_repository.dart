import '../models/note.dart';

abstract interface class NoteRepository {
  Future<void> initialize();
  Future<List<Note>> getAll();
  Future<void> save(Note note);
  Future<void> delete(String id);
}

enum StorageMode { sqlite, files }

extension StorageModeLabel on StorageMode {
  String get label => switch (this) {
        StorageMode.sqlite => 'SQLite',
        StorageMode.files => 'Файлы JSON',
      };
}
