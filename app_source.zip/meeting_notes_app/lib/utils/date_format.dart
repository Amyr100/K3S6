String twoDigits(int value) => value.toString().padLeft(2, '0');

String formatDate(DateTime date) =>
    '${twoDigits(date.day)}.${twoDigits(date.month)}.${date.year}';

String formatTime(DateTime date) =>
    '${twoDigits(date.hour)}:${twoDigits(date.minute)}';

String formatDateTime(DateTime date) =>
    '${formatDate(date)} в ${formatTime(date)}';
