import 'package:flutter_test/flutter_test.dart';
import 'package:meeting_notes_app/models/note.dart';

void main() {
  group('Note', () {
    test('converts to map and back without losing fields', () {
      final eventAt = DateTime(2026, 11, 5, 14, 30);
      final createdAt = DateTime(2026, 11, 1, 9, 15);
      final updatedAt = DateTime(2026, 11, 3, 10, 20);
      final original = Note(
        id: 'note-1',
        title: 'План совещания',
        content: 'Обсудить сроки проекта',
        eventAt: DateTime(2026, 11, 5, 14, 30),
        createdAt: DateTime(2026, 11, 1, 9, 15),
        updatedAt: DateTime(2026, 11, 3, 10, 20),
      );

      final restored = Note.fromMap(original.toMap());

      expect(restored.id, 'note-1');
      expect(restored.title, 'План совещания');
      expect(restored.content, 'Обсудить сроки проекта');
      expect(restored.eventAt, eventAt);
      expect(restored.createdAt, createdAt);
      expect(restored.updatedAt, updatedAt);
    });

    test('copyWith preserves id and creation time', () {
      final original = Note.create(
        title: 'До изменения',
        content: 'Текст',
        eventAt: DateTime(2026, 11, 5, 14),
      );
      final changed = original.copyWith(title: 'После изменения');

      expect(changed.id, original.id);
      expect(changed.createdAt, original.createdAt);
      expect(changed.title, 'После изменения');
    });
  });
}
