@echo off
setlocal EnableExtensions
set "PROJECT_DIR=%~dp0flutter_project"

if not exist "%PROJECT_DIR%\pubspec.yaml" (
  echo First run setup_windows.bat to prepare the Flutter project.
  pause
  exit /b 1
)

where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter SDK was not found in PATH.
  pause
  exit /b 1
)

pushd "%PROJECT_DIR%"
flutter pub get
if errorlevel 1 goto failed
flutter build apk --release
if errorlevel 1 goto failed

echo.
echo APK created at:
echo %PROJECT_DIR%\build\app\outputs\flutter-apk\app-release.apk
popd
pause
exit /b 0

:failed
popd
echo APK build failed. Review the Flutter output above.
pause
exit /b 1
